VERTRAGSVERWALTUNG v1.0.0
=========================

🎉 Herzlichen Glückwunsch! Sie haben erfolgreich die Vertragsverwaltung heruntergeladen.

SCHNELLE INSTALLATION:
1. Alle Dateien in das Web-Root Ihres Hostings hochladen
2. Browser öffnen und zu Ihrer Domain navigieren
3. Automatischer Installations-Wizard startet
4. 6 einfache Schritte befolgen
5. Fertig! 🚀

SYSTEMANFORDERUNGEN:
- PHP 8.1+ mit Extensions: pdo_mysql, sodium, intl, mbstring, fileinfo
- MySQL 8.0+ oder MariaDB 10.5+
- Apache Webserver mit mod_rewrite

DETAILLIERTE ANLEITUNG:
Siehe INSTALLATION.md für vollständige Installationsanweisungen.

SUPPORT:
- GitHub: https://github.com/fksnet/vertragsverwaltung
- Issues: Bug-Reports via GitHub Issues

Viel Erfolg mit Ihrer neuen Vertragsverwaltung! 📋
